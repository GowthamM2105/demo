import 'package:demo/features/countries/data/remote/country_repository_impl.dart';
import 'package:demo/features/countries/domain/repository/country_repository.dart';
import 'package:demo/features/countries/presentation/bloc/country_bloc/country_bloc.dart';
import 'package:get_it/get_it.dart';

///[NOTE] : input for [Global] data state
final injector = GetIt.instance;

Future<void> init() async {
  injector.registerFactory<CountryRepository>(() => CountryRepositoryImpl());
  injector.registerFactory<CountryBloc>(
      () => CountryBloc(countryRepository: injector()));
}
