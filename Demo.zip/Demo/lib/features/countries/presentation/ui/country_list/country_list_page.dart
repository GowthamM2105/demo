import 'package:demo/features/countries/domain/model/country.dart';
import 'package:demo/features/countries/presentation/bloc/country_bloc/country_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CountriesListPage extends StatelessWidget {
  const CountriesListPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bloc = context.read<CountryBloc>();

    return Scaffold(
        appBar: AppBar(
          title: const Text('Country List'),
        ),
        body: BlocBuilder(
          bloc: bloc,
          builder: (context, state) {
            if (state is CountriesLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is CountriesLoaded) {
              return _buildCountryListWidget(state.countries);
            } else {
              return const SizedBox.shrink();
            }
          },
        ));
  }

  Widget _buildCountryListWidget(List<Country> countryList) {
    return ListView.builder(
        itemCount: countryList.length,
        itemBuilder: (context, index) {
          final Country country = countryList.elementAt(index);
          return InkWell(
            onTap: () {
              // Navigator.of(context).push(
              //   MaterialPageRoute(
              //     builder: (context) => CountryDetailsWidget(
              //       countryName: country.commonName,
              //     ),
              //   ),
              // );
            },
            child: ListTile(
              title: Text(country.commonName),
              subtitle: Text(country.officialName),
            ),
          );
        });
  }
}
