part of 'country_bloc.dart';

abstract class CountryState extends Equatable {
  const CountryState();

  @override
  List<Object> get props => [];
}

class CountryInitial extends CountryState {}

class CountriesLoading extends CountryState {}

class CountriesLoaded extends CountryState {
  final List<Country> countries;

  const CountriesLoaded(this.countries);
}


class CountryDetailsLoaded extends CountryState {
  final Country country;

  const CountryDetailsLoaded(this.country);
}

class CountriesError extends CountryState {
  final String? errorMessage;

  const CountriesError({this.errorMessage});
}
