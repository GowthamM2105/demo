import 'dart:async';

import 'package:demo/features/countries/domain/model/country.dart';
import 'package:demo/features/countries/domain/repository/country_repository.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'country_event.dart';

part 'country_state.dart';

class CountryBloc extends Bloc<CountryEvent, CountryState> {
  CountryBloc({required CountryRepository countryRepository})
      : _countryRepository = countryRepository,
        super(CountryInitial()) {
    on<LoadCountriesEvent>(_loadCountriesEvent);
    on<LoadCountryDetailsEvent>(_loadCountryDetailsEvent);
  }

  final CountryRepository _countryRepository;

  FutureOr<void> _loadCountriesEvent(
      LoadCountriesEvent event, Emitter<CountryState> emit) async {
    emit(CountriesLoading());
    final countryList = await _countryRepository.getAllCountryList();
    emit(countryList != null
        ? CountriesLoaded(countryList)
        : const CountriesError());
  }

  FutureOr<void> _loadCountryDetailsEvent(
      LoadCountryDetailsEvent event, Emitter<CountryState> emit) async {
    emit(CountriesLoading());
    final country =
        await _countryRepository.getCountryDetailsByName(event.countryName);
    emit(country != null
        ? CountryDetailsLoaded(country)
        : const CountriesError());
  }
}
