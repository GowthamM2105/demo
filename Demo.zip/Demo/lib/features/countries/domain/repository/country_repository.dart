import 'package:demo/features/countries/domain/model/country.dart';

abstract class CountryRepository {
  Future<List<Country>?> getAllCountryList();

  Future<Country?> getCountryDetailsByName(String countryName);
}
