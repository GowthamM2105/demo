class Country {
  late String commonName;
  late String officialName;
  String? capital;
  String? region;
  String? subregion;
  List<String>? languages;

  Country({
    required this.commonName,
    required this.officialName,
    this.capital,
    this.subregion,
    this.region,
    this.languages,
  });

  Country.fromJson(Map<String, dynamic> json) {
    commonName = json['name']['common'];
    officialName = json['name']['official'];
    // capital = json['capital'];
    region = json['region'];
    subregion = json['subregion'];
    if (json['languages'] != null && json.containsKey('languages')) {
      Map<String, dynamic> languagesMap = json['languages'];
      languages = [];
      languagesMap.forEach((key, value) {
        languages?.add(value);
      });
    }
  }
}
