import 'dart:convert';
import 'dart:io';

import 'package:demo/features/countries/data/url_constants.dart';
import 'package:demo/features/countries/domain/model/country.dart';
import 'package:demo/features/countries/domain/repository/country_repository.dart';
import 'package:http/http.dart' as http;

class CountryRepositoryImpl extends CountryRepository {
  final headersMap = {'Host': 'restcountries.com'};

  @override
  Future<List<Country>?> getAllCountryList() async {
    List<Country>? countries;

    try {
      final http.Response response = await http
          .get(Uri.parse(URLConstants.allCountries), headers: headersMap);
      if (response.statusCode == HttpStatus.ok) {
        List<dynamic> countriesMap = jsonDecode(response.body.toString());
        countries = countriesMap.map((e) => Country.fromJson(e)).toList();
      }
    } catch (e) {
      print(e);
    }
    return countries;
  }

  @override
  Future<Country?> getCountryDetailsByName(String countryName) async {
    final http.Response response = await http
        .get(Uri.parse(URLConstants.countryDetailsByName + countryName));
    List<Country>? countries;
    if (response.statusCode == HttpStatus.ok) {
      List<dynamic> countriesMap = jsonDecode(response.body);
      countries = countriesMap.map((e) => Country.fromJson(e)).toList();
    }
    return countries != null && countries.isNotEmpty ? countries.first : null;
  }
}
