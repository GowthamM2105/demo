class URLConstants {
  static const _baseURL = 'https://restcountries.com/';
  static const _version = 'v3.1';

  //API
  static const allCountries = '$_baseURL$_version/all';
  static const countryDetailsByName = '$_baseURL$_version/name/';
}
