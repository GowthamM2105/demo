import 'package:demo/common/di/injection_container.dart';
import 'package:demo/features/countries/presentation/bloc/country_bloc/country_bloc.dart';
import 'package:demo/features/countries/presentation/ui/country_list/country_list_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';

import 'mocks/mock_country_bloc.dart';

void main() {
  setUpAll(() {
    injector.registerMockCountryBloc();
  });

  group('verify country list UI', () {
    testWidgets(
        'WHEN country list is available,'
        'THEN expect name and official name is present in the UI',
        (WidgetTester tester) async {
      // Build our app and trigger a frame.

      await tester.pumpWidget(
        MediaQuery(
          data: const MediaQueryData(size: Size(600, 740)),
          child: MaterialApp(
            home: MultiBlocProvider(
              providers: [
                BlocProvider<CountryBloc>.value(
                    value: injector.get<CountryBloc>())
              ],
              child: const CountriesListPage(),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      // Verify that our counter starts at 0.
      expect(find.text('Cyprus'), findsOneWidget);
      expect(find.text('Republic of Cyprus'), findsOneWidget);
    });
  });
}
