import 'package:bloc_test/bloc_test.dart';
import 'package:demo/features/countries/domain/model/country.dart';
import 'package:demo/features/countries/domain/repository/country_repository.dart';
import 'package:demo/features/countries/presentation/bloc/country_bloc/country_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mocktail/mocktail.dart';

void main() {
  group('verify bloc states', () {
    blocTest(
      'WHEN bloc hs its initial state,'
      ' THEN expect the result of state emit is []',
      build: () => CountryBloc(countryRepository: MockCountryRepository()),
      expect: () => [],
    );

    blocTest(
      'WHEN the cpuntries are loaded,'
      'THEN expect the state is initially Countries loading and changed to Counties loaded',
      build: () => CountryBloc(countryRepository: MockCountryRepository()),
      act: (bloc) => bloc.add(LoadCountriesEvent()),
      expect: () => [CountriesLoading(), const CountriesLoaded([])],
    );
  });
}

class MockCountryRepository extends Mock implements CountryRepository {
  @override
  Future<List<Country>?> getAllCountryList() async {
    return [];
  }
}
