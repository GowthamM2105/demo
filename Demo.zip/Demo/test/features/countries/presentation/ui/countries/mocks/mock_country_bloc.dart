import 'package:bloc_test/bloc_test.dart';
import 'package:demo/features/countries/domain/model/country.dart';
import 'package:demo/features/countries/presentation/bloc/country_bloc/country_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:mocktail/mocktail.dart';

class MockCountryBloc extends MockBloc<CountryEvent, CountryState>
    implements CountryBloc {
  MockCountryBloc() : super();
}

class FakeCountryEvent extends Fake implements CountryEvent {}

class FakeCountryState extends Fake implements CountryState {}

late final MockCountryBloc mockCountryBloc;

setupMockCountryBloc() {
  registerFallbackValue(FakeCountryEvent());
  registerFallbackValue(FakeCountryState());

  mockCountryBloc = MockCountryBloc();

  final countries = [
    Country(
        commonName: 'Cyprus',
        officialName: 'Republic of Cyprus',
        capital: "",
        subregion: "",
        region: "",
        languages: [""])
  ];

  whenListen(
    mockCountryBloc,
    Stream.fromIterable(<CountryState>[]),
    initialState: CountriesLoaded(countries),
  );
}

extension InjectorMockBloc on GetIt {
  void registerMockCountryBloc() {
    setupMockCountryBloc();
    registerFactory<CountryBloc>(() => mockCountryBloc);
  }
}
